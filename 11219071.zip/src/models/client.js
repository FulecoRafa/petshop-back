const mongoose = require('mongoose');

const schema = new mongoose.Schema({
  name:{
    type: String,
    trim: true,
    unique: true,
    required: [true, "No client name provided"]
  },
  email:{
    type: String,
    required: [true, "No client email provided"]
  },
  passwd:{
    type: String,
    required: [true, "No client email provided"]
  }
});

module.exports = mongoose.model('Client', schema);