const routes = require('express').Router();

const controller = require('../controllers/client');

routes.get('/id/:id', controller.getById);
routes.get('/username/:name', controller.getByUsername);
routes.post('/', controller.create);

module.exports = routes;