const routes = require('express').Router();

const controller = require('../controllers/order');

routes.get('/', controller.get);
routes.post('/', controller.create);

module.exports = routes;