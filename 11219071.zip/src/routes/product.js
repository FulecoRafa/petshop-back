const routes = require('express').Router();

const controller = require('../controllers/product');

routes.get('/', controller.get);
routes.get('/slug/:slug', controller.getBySlug);
routes.get('/id/:id', controller.getById);
routes.get('/tag/:tag', controller.getByTag);
routes.post('/', controller.create);
routes.put('/:id', controller.update);
routes.delete('/:id', controller.delete);

module.exports = routes;