const mongoose = require('mongoose');
const Order = mongoose.model('Order');

module.exports = {
  get(req, res, next){
    Order.find({}, 'createdAt status')
      .populate('customer', 'name -_id')
      .populate('items.product', 'title -_id')
      .then(data=>{
        res.status(200).send(data)
      })
      .catch(error=>{
        res.status(400).send(error)
      })
  },
  create(req, res, next){
    Order.create(req.body)
      .then(data=>{
        res.status(201).send("Succesfully created product");
      })
      .catch(error=>{
        res.status(400).send(error);
      })
  },

}