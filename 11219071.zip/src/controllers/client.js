const mongoose = require('mongoose');
const Client = mongoose.model('Client');

module.exports = {
  getById(req, res, next){
    Client.findById(req.params.id)
      .then(data=>{
        res.status(200).send(data);
      })
      .catch(error=>{
        res.status(400).send("Couldn't find client");
      });
  },
  getByUsername(req, res, next){
    Client.findOne({ name: req.params.name})
      .then(data=>{
        res.status(200).send(data);
      })
      .catch(error=>{
        res.status(400).send("Username not found");
      });
  },
  create(req, res, next){
    Client.create(req.body)
      .then(data=>{
        res.status(201).send(data);
      })
      .catch(error=>{
        res.status(400).send("Couldn't create client");
      });
  }
}